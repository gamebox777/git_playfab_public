﻿効果音素材：ポケットサウンド様
https://pocket-se.info/

二次配布にならないようにするため、効果音素材はリポジトリには含めていません。
利用者は各自で以下のファイルをダウンロードして、このフォルダに配置してください。

countdown.mp3
https://pocket-se.info/archives/398/

mistake.mp3
https://pocket-se.info/archives/811/

result.mp3
https://pocket-se.info/archives/1116/

right2.mp3
https://pocket-se.info/archives/808/
