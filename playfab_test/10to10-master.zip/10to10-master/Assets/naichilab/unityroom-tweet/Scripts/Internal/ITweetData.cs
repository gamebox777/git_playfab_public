﻿namespace naichilab.Scripts.Internal
{
    public interface ITweetData
    {
        string GetShareUrl();
    }
}