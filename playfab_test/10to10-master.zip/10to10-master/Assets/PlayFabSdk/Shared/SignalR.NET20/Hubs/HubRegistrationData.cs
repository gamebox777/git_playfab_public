﻿#if ENABLE_PLAYFABPLAYSTREAM_API && ENABLE_PLAYFABSERVER_API
namespace SignalR.Client._20.Hubs
{
    public class HubRegistrationData
    {
        public string Name { get; set; }
    }
}

#endif