#if ENABLE_PLAYFABADMIN_API
using System;
using UnityEngine;
using System.Collections;
using PlayFab.Internal;

namespace PlayFab
{
    public static partial class PlayFabSettings
    {

    }
}
#endif
